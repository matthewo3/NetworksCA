var app = require('express')();
var http = require('http').Server(app);
var io = require('socket.io')(http);
var port = process.env.PORT || 3000;
nicknames = [];

app.get('/', function(req, res){
  res.sendFile(__dirname + '/public/index.html');
});

io.on('connection', function(socket){
  /*socket.on('new user message', function(msg, callback){
	  //checking to see if the nickname entered doesnt get back a negative 1
	  if(nicknames.indexOf (msg) != -1){
		  callback(false);
	  }else{
		  callback(true);
		  socket.nickname = msg;
		  nickname.push(socket.nickname);
		  //adding the username into the usernames array
		  io.sockets.emit('usernames',nicknames);
		  
	  }
  });*/
  
  socket.on('chat message', function(msg){
    io.emit('chat message', msg);
  });
});


http.listen(port, function(){
  console.log('listening on *:' + port);
});

io.on('connection', function(client) {  
	console.log('A user connected');
	//when a new user connects
	io.clients(function(error, clients){
	  if (error) throw error;
		//send the list of clients out to all the clients
		io.emit('clientList', clients);
		console.log(clients);
	});
	
});
